package vista;
import conexion.Conexion;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class datosRedesCreadas extends javax.swing.JFrame {
Conexion cn = new Conexion();
    Connection con;
    DefaultTableModel model;
    Statement st;
    ResultSet rs;
    int id = 0;
    
    public datosRedesCreadas() {
        initComponents();
        setLocationRelativeTo(null);
        listar();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaRed = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Redes creadas");

        tablaRed.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "idCompra", "nombre", "apellido", "DNI", "direccion IP", "caracteristicas", "precio", "fecha compra"
            }
        ));
        jScrollPane1.setViewportView(tablaRed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 803, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(343, 343, 343))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new datosRedesCreadas().setVisible(true);
            }
        });
    }
    
    void listar() {
        String sql = "SELECT solicitarednueva.idCompraRedNueva, persona.nombrePersona, persona.apellidoPersona, persona.DNI, rednueva.direccionIp, rednueva.caracteristicas, rednueva.precio, solicitarednueva.fechaCompra FROM solicitarednueva INNER JOIN persona ON persona.idPersona = solicitarednueva.idCliente INNER JOIN rednueva ON rednueva.idRedNueva = solicitarednueva.idRedNueva";
        try {
            con = cn.getConnection();
            st = con.createStatement();
            rs = st.executeQuery(sql);
            Object[] datosEmpleado = new Object[8];  
            model = (DefaultTableModel) tablaRed.getModel();
            while (rs.next()) {
                datosEmpleado[0] = rs.getInt("idCompraRedNueva");               
                datosEmpleado[1] = rs.getString("nombrePersona");
                datosEmpleado[2] = rs.getString("apellidoPersona");
                datosEmpleado[3] = rs.getInt("DNI");
                datosEmpleado[4] = rs.getString("direccionIp");
                datosEmpleado[5] = rs.getString("caracteristicas");
                datosEmpleado[6] = rs.getDouble("precio");
                datosEmpleado[7] = rs.getDate("fechaCompra"); 
                model.addRow(datosEmpleado);
            }
            tablaRed.setModel(model);

        } catch (Exception e) {
        }

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaRed;
    // End of variables declaration//GEN-END:variables
}
