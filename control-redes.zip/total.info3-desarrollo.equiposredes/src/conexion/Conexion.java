
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    
    Connection con;
    public Conexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://192.168.3.253:3306/totalinfo3?auroReconnect=true&useSSL=false","facu","facu");
        } catch (Exception e) {
            System.err.println("Error:"+e);
        }        
    }
    public Connection getConnection(){
        return con;
    }
    
}
